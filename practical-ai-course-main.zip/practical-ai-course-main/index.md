---
title: Home
layout: home
---

Welcome to the official course resource hub! Right now, you’ll find essential materials and links to support your learning. But we’re just getting started—over time, we’ll be adding FAQs, troubleshooting guides, bonus content, and more based on your feedback. Check back often, and if you have any questions or suggestions, let us know!

alessi.courses [at] gmail.com

----

[Just the Docs]: https://just-the-docs.github.io/just-the-docs/
[GitHub Pages]: https://docs.github.com/en/pages
[README]: https://github.com/just-the-docs/just-the-docs-template/blob/main/README.md
[Jekyll]: https://jekyllrb.com
[GitHub Pages / Actions workflow]: https://github.blog/changelog/2022-07-27-github-pages-custom-github-actions-workflows-beta/
[use this template]: https://github.com/just-the-docs/just-the-docs-template/generate
